#!/bin/python

from sys import argv

script, first, second, third, fourth = argv

print "The script is called:", script
print "Your first variable is:", first
print "Your second varible is:", second
print "Your third variable is:", third
print "Your fourth varible is:", fourth
fith = raw_input("enter your fith variable:")

print "enter your fith var is %r:" % (fith)
