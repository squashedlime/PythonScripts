weappwr = {1: "5,30", 2: "25,50"}
for value, pwr in weappwr.items():
	print "blaster has this power %s and is choice %s" % (pwr, value)
