from sys import argv

script, ext_value = argv
i = 0
numbers = []
arg1 = ext_value
#def new_arg(arg1):
for i in arg1:
    i + arg1
    print "at the top i is %r" % i
