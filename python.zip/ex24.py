print "Lets practice everything."
print "You\'d need to know \'bout escapes with \\ that do \n new lines and \t tabs."

poem = '''
\rThe lovely world
with logic so firmly planted
cannot discern \n the needs of love
nor comprehend passion from intuition
and requires and explanation
\n\t\twhere there is none.
'''
print "_________"
print poem
print "_________"

five = 10 - 2 + 3 -6
print "This should be five: %s" % five

def secret_formula(started):
	jelly_beans = started * 500
	jars = jelly_beans / 1000
	crates = jars / 100
	return jelly_beans, jars, crates

start_point = 10000
#here we allocate the three varible to sercret_formula which returns jelly_beans, jars, crates. so when we call beans on line 30
beans, jars, crates = secret_formula(start_point)

print "With a starting point of: %d" % start_point
print 'We\'d have %d beans, %d jars and %d crates.' % (beans, jars, crates)

start_point = start_point / 10

print "We can also do that this way:"
#here we use the function secret_formula and use start_point as the variable, we then get 3 variable out of the function that can fill beans, jars, crates.
print "We'd have %d beans, %d jars, adn %d crates." % secret_formula(start_point)

