from sys import argv

script, file = argv

txt = open(file)
print txt.read()
txt.close()
